function myFunction() {
    var x = document.getElementById("myInput");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }

  const passwordInput =document.getElementById("myInput")

  function ispassword(password){
    function isPasswordValid(password) {
        
        if (password.length < 8) {
          return false;
        }
      
        
        const lowercaseRegex = /[a-z]/;
        const uppercaseRegex = /[A-Z]/;
        const numberRegex = /\d/;
        if (!lowercaseRegex.test(password) || !uppercaseRegex.test(password) || !numberRegex.test(password)) {
          return false;
        }
      
        
        const username = "swasti";
        const usernameRegex = new RegExp(username, "i"); 
        if (usernameRegex.test(password)) {
          return false;
        }
      

        return true;
      }
      
  }

  function setPasswordValidityBorder() {
    if (isPasswordValid(passwordInput.value)) {
      passwordInput.style.borderColor = "green";
    } else {
      passwordInput.style.borderColor = "red";
    }
  }

  passwordInput.addEventListener("input", setPasswordValidityBorder);