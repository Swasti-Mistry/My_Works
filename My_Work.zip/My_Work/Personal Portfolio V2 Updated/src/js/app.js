// example of simple includes for js
//=include lib/jquery.min.js
//=include lib/owl.carousel.min.js
//=include lib/svg4everybody.min.js
//=include lib/aos.js
//=include lib/simpleParallax.min.js
